// ╔══════════════════════════════════════════╗
//   NEL SERVIÇOS · core/system/commands.js
// ╚══════════════════════════════════════════╝

export const bodyMenu = `
╔═══════════════════════════════╗
║   𖧧  *NEL SERVIÇOS*  ·  v4.0   ║
╚═══════════════════════════════╝

  ✦ Olá, *@$sender*! Sou *$namebot* ✦

❝ *Nel* — onde cada comando é uma
  obra de arte na palma da tua mão. ❞

┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄

╭─ 〘 PROPRIETÁRIO 〙 ──────────╮
│  ★  Nome      Nel Custódio     │
│  ◈  Cargo     Principal/Owner  │
│  ◈  Contato   878038315        │
│  ◈  País      Moçambique 🇲🇿   │
│  ◈  Projecto  Nel Serviços     │
╰─────────────────────────────────╯

╭─ 〘 SISTEMA 〙 ───────────────╮
│  ⬡  Versão    4.0 · Latest     │
│  ⬡  Sistema   Android          │
│  ⬡  Hora      $tiempo          │
│  ⬡  Users     $users           │
│  ⬡  URL       yuki-wabot.my.id │
╰─────────────────────────────────╯

  ▸ Use *.qr* ou *.code* para vincular
    seu número a um Socket.

┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄

  ◉ *CATEGORIAS*

  ❰ 💰 ❱  .menu economia
  ❰ 🎴 ❱  .menu gacha
  ❰ ⬇️ ❱  .menu downloads
  ❰ 👤 ❱  .menu perfil
  ❰ 🤖 ❱  .menu sockets
  ❰ 🖼️ ❱  .menu stickers
  ❰ 🛠️ ❱  .menu utilidades
  ❰ 👥 ❱  .menu grupos
  ❰ 🔞 ❱  .menu nsfw
  ❰ 🌸 ❱  .menu anime

┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
    ✧ *.menu <categoria>* ✧`

// ─────────────────────────────────────────────
export const menuObject = {

// ══════════════════════════════════════════════
economia: `
╔═══════════════════════════════╗
║   💰  *ECONOMIA*  ·  Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Ganhe coins, aposte e divirta-se.

  ┌─ 〘 TRABALHO & RENDA 〙 ──────┐
  │  .w » .work                     │
  │    Trabalhar e ganhar coins      │
  │  .crime                         │
  │    Ganhar coins rápido           │
  │  .slut                          │
  │    Ganhar coins modo ousado      │
  │  .mine » .minar                 │
  │    Minerar coins                 │
  │  .cazar » .hunt                 │
  │    Caçar animais                 │
  │  .pescar » .fish                │
  │    Pescar e ganhar coins         │
  └─────────────────────────────────┘

  ┌─ 〘 RECOMPENSAS 〙 ───────────┐
  │  .daily                         │
  │    Recompensa diária             │
  │  .weekly                        │
  │    Recompensa semanal            │
  │  .monthly                       │
  │    Recompensa mensal             │
  │  .cofre » .coffer               │
  │    Baú diário                    │
  └─────────────────────────────────┘

  ┌─ 〘 BANCO 〙 ─────────────────┐
  │  .bal » .balance + <@>          │
  │    Ver seus coins                │
  │  .dep » .deposit + <v|all>      │
  │    Depositar no banco            │
  │  .sacar » .withdraw + <v|all>   │
  │    Sacar do banco                │
  │  .pay » .givecoins + <v> <@>    │
  │    Dar coins a alguém            │
  │  .baltop » .eboard + <p>        │
  │    Ranking de coins              │
  │  .einfo » .economyinfo          │
  │    Info economia do grupo        │
  └─────────────────────────────────┘

  ┌─ 〘 APOSTAS 〙 ───────────────┐
  │  .cf » .coinflip + <v> <c|k>   │
  │    Cara ou coroa                 │
  │  .rt » .roulette + <v> <cor>    │
  │    Roleta                        │
  │  .casino » .slot + <v>          │
  │    Slot machine                  │
  │  .roubar » .steal + <@>         │
  │    Tentar roubar alguém          │
  └─────────────────────────────────┘

  ┌─ 〘 RPG & AVENTURA 〙 ────────┐
  │  .aventura » .adventure         │
  │    Ir em aventura                │
  │  .heal » .curar                 │
  │    Curar HP                      │
  │  .dungeon » .mazmorra           │
  │    Explorar masmorra             │
  │  .math » .mates + <dif>         │
  │    Quiz de matemática            │
  │  .ppt + <pedra|papel|tesoura>   │
  │    Pedra papel tesoura           │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
gacha: `
╔═══════════════════════════════╗
║   🎴  *GACHA*  ·  Nel Bot      ║
╚═══════════════════════════════╝
  ✦ Reivindique e troque personagens.

  ┌─ 〘 REIVINDICAR 〙 ──────────┐
  │  .roll » .rw                    │
  │    Personagem aleatório          │
  │  .claim » .c + <waifu>          │
  │    Reivindicar personagem        │
  │  .setclaim + <texto>            │
  │    Editar msg de claim           │
  │  .delclaim                      │
  │    Resetar msg de claim          │
  │  .delwaifu » .delchar + <w>     │
  │    Deletar personagem            │
  └─────────────────────────────────┘

  ┌─ 〘 COLEÇÃO 〙 ───────────────┐
  │  .harem » .waifus + <@>         │
  │    Ver harém                     │
  │  .ginfo » .gachainfo            │
  │    Info de gacha                 │
  │  .favtop » .favoritetop         │
  │    Top favoritos                 │
  │  .wtop » .waifustop + <p>       │
  │    Top por valor                 │
  └─────────────────────────────────┘

  ┌─ 〘 LOJA 〙 ─────────────────┐
  │  .wshop » .haremshop + <p>      │
  │    Ver loja de personagens       │
  │  .buy » .buychar + <waifu>      │
  │    Comprar personagem            │
  │  .vender » .sell + <v> <w>      │
  │    Colocar à venda               │
  │  .removew » .removesale + <w>   │
  │    Remover da venda              │
  └─────────────────────────────────┘

  ┌─ 〘 TROCA & PRESENTE 〙 ──────┐
  │  .give » .givewaifu + <w> <@>   │
  │    Dar personagem                │
  │  .giveall » .giveallharem + <@> │
  │    Dar todo o harém              │
  │  .trade » .intercambiar + <c>   │
  │    Trocar personagem             │
  │  .votar » .vote + <waifu>       │
  │    Votar em personagem           │
  └─────────────────────────────────┘

  ┌─ 〘 INFO 〙 ─────────────────┐
  │  .wimage » .cimage + <waifu>    │
  │    Imagem aleatória              │
  │  .winfo » .charinfo + <waifu>   │
  │    Detalhes do personagem        │
  │  .serie » .animeinfo + <nome>   │
  │    Info de anime                 │
  │  .serielist » .animelist        │
  │    Listar séries                 │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
downloads: `
╔═══════════════════════════════╗
║   ⬇️  *DOWNLOADS* ·  Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Baixe mídias de qualquer fonte.

  ┌─ 〘 VÍDEO 〙 ────────────────┐
  │  .play2 » .mp4 » .ytmp4         │
  │    YouTube (MP4)                 │
  │  .tt » .tiktok + <url>          │
  │    TikTok                        │
  │  .ig » .reel » .instagram       │
  │    Instagram Reel                │
  │  .fb » .facebook + <url>        │
  │    Facebook                      │
  │  .x » .twitter + <url>          │
  │    Twitter / X                   │
  └─────────────────────────────────┘

  ┌─ 〘 MÚSICA 〙 ───────────────┐
  │  .play » .mp3 » .ytmp3          │
  │    YouTube (MP3)                 │
  └─────────────────────────────────┘

  ┌─ 〘 IMAGENS 〙 ──────────────┐
  │  .img » .imagen + <busca>       │
  │    Google Imagens                │
  │  .pin » .pinterest + <url>      │
  │    Pinterest                     │
  └─────────────────────────────────┘

  ┌─ 〘 ARQUIVOS 〙 ─────────────┐
  │  .mf » .mediafire + <url>       │
  │    MediaFire                     │
  │  .drive » .gdrive + <url>       │
  │    Google Drive                  │
  │  .apk » .aptoide + <busca>      │
  │    APK (Aptoide)                 │
  │  .git » .gitclone + <url>       │
  │    Repositório GitHub            │
  └─────────────────────────────────┘

  ┌─ 〘 BUSCA 〙 ────────────────┐
  │  .ytsearch » .ys + <busca>      │
  │    Buscar no YouTube             │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
perfil: `
╔═══════════════════════════════╗
║   👤  *PERFIL*  ·  Nel Bot     ║
╚═══════════════════════════════╝
  ✦ Veja e configure seu perfil.

  ┌─ 〘 VER 〙 ──────────────────┐
  │  .perfil » .profile + <@>       │
  │    Ver perfil                    │
  │  .lvl » .level + <@>            │
  │    Nível e XP atual              │
  │  .lb » .leaderboard + <p>       │
  │    Ranking de XP                 │
  └─────────────────────────────────┘

  ┌─ 〘 CONFIGURAR 〙 ───────────┐
  │  .setgen » .setgenre + <g>      │
  │    Definir gênero                │
  │  .setbirth + <dd/mm/aaaa>       │
  │    Data de aniversário           │
  │  .setdesc » .setdescription     │
  │    Sua descrição                 │
  │  .sethobby » .setpasatiempo     │
  │    Seu passatempo                │
  │  .setfav » .setfavourite + <w>  │
  │    Waifu favorita                │
  └─────────────────────────────────┘

  ┌─ 〘 DELETAR 〙 ──────────────┐
  │  .delgen » .delgenre            │
  │    Remover gênero                │
  │  .delbirth                      │
  │    Remover aniversário           │
  │  .deldesc » .deldescription     │
  │    Remover descrição             │
  │  .delhobby » .delpasatiempo     │
  │    Remover passatempo            │
  │  .delfav » .deletefav + <w>     │
  │    Remover favorita              │
  └─────────────────────────────────┘

  ┌─ 〘 RELACIONAMENTO 〙 ───────┐
  │  .casar » .marry + <@>          │
  │    Casar com alguém              │
  │  .divorcio » .divorce           │
  │    Divorciar-se                  │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
sockets: `
╔═══════════════════════════════╗
║   🤖  *SOCKETS*  ·  Nel Bot    ║
╚═══════════════════════════════╝
  ✦ Gerencie seu próprio bot.

  ┌─ 〘 SESSÃO 〙 ───────────────┐
  │  .qr » .code                    │
  │    Criar Sub-Bot (QR/Code)       │
  │  .botinfo » .infobot            │
  │    Info do bot                   │
  │  .reload                        │
  │    Recarregar sessão             │
  │  .logout                        │
  │    Encerrar sessão               │
  └─────────────────────────────────┘

  ┌─ 〘 GRUPOS 〙 ───────────────┐
  │  .join + <link>                 │
  │    Entrar em grupo               │
  │  .leave » .salir                │
  │    Sair do grupo                 │
  │  .self + <on|off>               │
  │    Modo privado / público        │
  └─────────────────────────────────┘

  ┌─ 〘 APARÊNCIA 〙 ────────────┐
  │  .setname » .setbotname + <n>   │
  │    Nome do bot                   │
  │  .setpfp » .setimage            │
  │    Foto de perfil                │
  │  .setbanner » .setbotbanner     │
  │    Banner do menu                │
  │  .seticon » .setboticon         │
  │    Ícone do bot                  │
  │  .setstatus + <valor>           │
  │    Status do bot                 │
  │  .setuser » .setusername        │
  │    Username do bot               │
  └─────────────────────────────────┘

  ┌─ 〘 CONFIGURAÇÕES 〙 ────────┐
  │  .setprefix » .setbotprefix     │
  │    Prefixo do bot                │
  │  .setmoeda » .setcurrency       │
  │    Moeda do bot                  │
  │  .setowner » .setbotowner + <@> │
  │    Dono do bot                   │
  │  .setchannel » .setbotchannel   │
  │    Canal do bot                  │
  │  .setlink » .setbotlink         │
  │    Link do bot                   │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
stickers: `
╔═══════════════════════════════╗
║   🖼️  *STICKERS*  ·  Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Crie e gerencie figurinhas.

  ┌─ 〘 CRIAR 〙 ────────────────┐
  │  .s » .sticker + <imagem>       │
  │    Converter em sticker          │
  │  .brat » .bratv + <texto>       │
  │    Sticker com texto             │
  │  .toimg » .toimage              │
  │    Sticker → imagem              │
  └─────────────────────────────────┘

  ┌─ 〘 PACOTES 〙 ──────────────┐
  │  .packs » .packlist             │
  │    Listar seus pacotes           │
  │  .newpack + <nome>              │
  │    Criar pacote                  │
  │  .delpack + <nome>              │
  │    Deletar pacote                │
  │  .getpack » .pack + <nome>      │
  │    Baixar pacote                 │
  │  .privpack » .setpackpriv       │
  │    Tornar privado                │
  │  .pubpack » .setpackpub         │
  │    Tornar público                │
  └─────────────────────────────────┘

  ┌─ 〘 GERENCIAR 〙 ────────────┐
  │  .addsticker » .stickeradd      │
  │    Adicionar ao pacote           │
  │  .delsticker » .stickerdel      │
  │    Remover do pacote             │
  │  .setmeta » .setstickermeta     │
  │    Pack e autor padrão           │
  │  .delmeta » .delstickermeta     │
  │    Resetar padrão                │
  │  .setnamepack » .setpackname    │
  │    Renomear pacote               │
  │  .setdescpack » .setpackdesc    │
  │    Descrição do pacote           │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
utilidades: `
╔═══════════════════════════════╗
║   🛠️  *UTILIDADES* · Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Ferramentas para o dia a dia.

  ┌─ 〘 BOT 〙 ──────────────────┐
  │  .ping » .speed                 │
  │    Latência do bot               │
  │  .status » .estado              │
  │    Estado do bot                 │
  │  .bots » .sockets               │
  │    Bots ativos                   │
  │  .menu + <categoria>            │
  │    Ver menu                      │
  └─────────────────────────────────┘

  ┌─ 〘 MÍDIA 〙 ────────────────┐
  │  .pfp » .getpic + <@>           │
  │    Foto de perfil                │
  │  .hd » .enhance » .remini       │
  │    Melhorar imagem               │
  │  .tourl + <imagem>              │
  │    Mídia → link                  │
  │  .read » .readviewonce          │
  │    Converter view-once           │
  └─────────────────────────────────┘

  ┌─ 〘 IA & TEXTO 〙 ───────────┐
  │  .ia » .chatgpt + <pergunta>    │
  │    Perguntar ao ChatGPT          │
  │  .trad » .translate + <l> <t>   │
  │    Traduzir texto                │
  │  .say » .decir + <texto>        │
  │    Repetir mensagem              │
  └─────────────────────────────────┘

  ┌─ 〘 WEB & DEV 〙 ────────────┐
  │  .get » .fetch + <url>          │
  │    Requisição GET                │
  │  .git » .gitclone + <url>       │
  │    Baixar repositório            │
  │  .inspect » .inspeccionar       │
  │    Info de grupo/canal WA        │
  └─────────────────────────────────┘

  ┌─ 〘 SUPORTE 〙 ──────────────┐
  │  .report » .reporte + <erro>    │
  │    Reportar erro                 │
  │  .sug » .suggest + <texto>      │
  │    Enviar sugestão               │
  │  .invite » .invitar + <link>    │
  │    Convidar bot                  │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
grupos: `
╔═══════════════════════════════╗
║   👥  *GRUPOS ADM* · Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Comandos para administradores.

  ┌─ 〘 MEMBROS 〙 ──────────────┐
  │  .kick + <@>                    │
  │    Expulsar membro               │
  │  .promote + <@>                 │
  │    Promover a ADM                │
  │  .demote + <@>                  │
  │    Rebaixar ADM                  │
  │  .tagall » .tag » .hidetag      │
  │    Mencionar todos               │
  └─────────────────────────────────┘

  ┌─ 〘 ADVERTÊNCIAS 〙 ─────────┐
  │  .warn + <@> <motivo>           │
  │    Advertir membro               │
  │  .warns + <@>                   │
  │    Ver advertências              │
  │  .delwarn + <@> <n|all>         │
  │    Remover advertência           │
  │  .warnlimit » .setwarnlimit     │
  │    Limite de warns               │
  └─────────────────────────────────┘

  ┌─ 〘 CONTROLE 〙 ─────────────┐
  │  .close » .cerrar + <tempo>     │
  │    Fechar grupo                  │
  │  .open » .abrir + <tempo>       │
  │    Abrir grupo                   │
  │  .bot + <on|off>                │
  │    Ativar/desativar bot          │
  │  .antilink » .antilinks         │
  │    Anti-links                    │
  │  .adminonly » .onlyadmin        │
  │    Só ADMs usam comandos         │
  │  .alerts » .alertas             │
  │    Alertas do grupo              │
  │  .clear                         │
  │    Limpar mensagens              │
  └─────────────────────────────────┘

  ┌─ 〘 BOAS-VINDAS 〙 ──────────┐
  │  .welcome » .bienvenida         │
  │    Ativar boas-vindas            │
  │  .bye » .goodbye » .despedida   │
  │    Ativar despedida              │
  │  .setwelcome + <valor>          │
  │    Msg de entrada                │
  │  .setbye » .setgoodbye          │
  │    Msg de saída                  │
  └─────────────────────────────────┘

  ┌─ 〘 INFO & STATS 〙 ─────────┐
  │  .gpinfo » .gp » .groupinfo     │
  │    Info do grupo                 │
  │  .topmsg » .topcount + <d>      │
  │    Top mensagens                 │
  │  .topinativo » .topinactive     │
  │    Top inativos                  │
  │  .msgcount » .count + <@>       │
  │    Contagem de msgs              │
  │  .link » .revoke                │
  │    Link do grupo                 │
  └─────────────────────────────────┘

  ┌─ 〘 APARÊNCIA 〙 ────────────┐
  │  .setgpname + <valor>           │
  │    Nome do grupo                 │
  │  .setgpdesc + <valor>           │
  │    Descrição do grupo            │
  │  .setgpimg » .setgpbaner        │
  │    Foto do grupo                 │
  └─────────────────────────────────┘

  ┌─ 〘 MÓDULOS 〙 ──────────────┐
  │  .economy » .economia           │
  │    Ativar economia               │
  │  .gacha » .rpg                  │
  │    Ativar gacha                  │
  │  .nsfw + <on|off>               │
  │    Ativar NSFW                   │
  │  .setprimary + <@>              │
  │    Bot primário                  │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
nsfw: `
╔═══════════════════════════════╗
║   🔞  *NSFW +18*  ·  Nel Bot   ║
╚═══════════════════════════════╝
  ✦ Apenas em grupos habilitados.

  ┌─ 〘 VÍDEOS 〙 ───────────────┐
  │  .xnxx + <busca|url>            │
  │    Buscar no XNXX                │
  │  .xvideos + <busca|url>         │
  │    Buscar no XVideos             │
  └─────────────────────────────────┘

  ┌─ 〘 IMAGENS 〙 ──────────────┐
  │  .danbooru » .dbooru + <tag>    │
  │    Danbooru                      │
  │  .gelbooru » .gbooru + <tag>    │
  │    Gelbooru                      │
  │  .r34 » .rule34 + <tag>         │
  │    Rule34                        │
  └─────────────────────────────────┘`,

// ══════════════════════════════════════════════
anime: `
╔═══════════════════════════════╗
║   🌸  *ANIME*  ·  Nel Bot      ║
╚═══════════════════════════════╝
  ✦ Reações para interagir com amigos.

  ┌─ 〘 PERSONAGENS 〙 ──────────┐
  │  .waifu » .neko                 │
  │    Waifu aleatória               │
  │  .ppcp » .ppcouple              │
  │    Imagens amizade/casal         │
  └─────────────────────────────────┘

  ┌─ 〘 CARINHO 〙 ──────────────┐
  │  .hug + <@>      Abraçar        │
  │  .kiss + <@>     Beijar         │
  │  .pat + <@>      Carinho        │
  │  .cuddle + <@>   Aconchegar     │
  │  .lick + <@>     Lamber         │
  └─────────────────────────────────┘

  ┌─ 〘 DIVERSÃO 〙 ─────────────┐
  │  .slap + <@>     Bofetada       │
  │  .bonk + <@>     Pancada        │
  │  .bite + <@>     Morder         │
  │  .kill + <@>     Matar          │
  └─────────────────────────────────┘

  ┌─ 〘 EXPRESSÕES 〙 ───────────┐
  │  .cry + <@>      Chorar         │
  │  .blush + <@>    Corar          │
  │  .smile + <@>    Sorrir         │
  │  .sad + <@>      Tristeza       │
  │  .happy + <@>    Alegria        │
  │  .angry + <@>    Raiva          │
  │  .shy + <@>      Timidez        │
  └─────────────────────────────────┘

  ┌─ 〘 AÇÕES 〙 ────────────────┐
  │  .dance + <@>    Dançar         │
  │  .wave + <@>     Acenar         │
  │  .wink + <@>     Piscar         │
  │  .run + <@>      Correr         │
  │  .eat + <@>      Comer          │
  └─────────────────────────────────┘
  ✦ _E muito mais reações..._`

} // fim menuObject

