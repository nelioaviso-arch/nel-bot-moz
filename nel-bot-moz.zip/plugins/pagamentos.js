let handler = async (m, { conn }) => {
await conn.sendMessage(m.chat, { text: `⬇️ *FORMAS DE PAGAMENTO* ⬇️

1️⃣ *M-PESA ❤️*
📲 858457134
👤 Nel Custódio 

2️⃣ *E-MOLA 🧡*
📲 878038315
👤 Nel Custódio 

> Após a transferência, envie o comprovativo anexado
> + O número do qual pretendes activar o pacote

. Obrigado! 🙏` }, { quoted: m });
}
handler.customPrefix = /^(pagamentos|formas de pagamento|pagar)$/i
handler.command = new RegExp
export default handler
