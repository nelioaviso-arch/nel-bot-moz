export let command = ['tabela', 'megas', 'net']
export let tags = ['main']
export let help = ['tabela', 'megas', 'net']

export async function handler(m, { conn }) {
let txt = `ᴍᴇɢᴀs ᴠᴏᴅᴀᴄᴏᴍ
🛜 ACTUALIZADA | Ativação Imediata | M-Pesa/E-Mola

📍 PACOTES DIÁRIOS (24H)
5MT ➜ 200MB 👌
10MT ➜ 400MB 🤛
15MT ➜ 600MB
20MT ➜ 800MB
25MT ➜ 1024MB 🌟🌟
30MT ➜ 1200MB
50MT ➜ 2048MB🔥
100MT ➜ 4096MB

📅 PACOTES MENSAIS (30 DIAS)
185MT ➜ 5.9GB💎 
220MT ➜ 7GB
450MT ➜ 17.2GB
870MT ➜ 35.6GB 👑
1800MT ➜ 71.5GB 🚀 MAX

━━━━━━━━━━━━━━
NEL NET Express!`
await conn.reply(m.chat, txt, m)
}

export default handler
